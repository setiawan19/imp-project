const express = require("express");
const mysql = require("mysql2");
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.json());

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE,
});

// GET all posts
app.get("/posts", (req, res) => {
  const { page, limit } = req.query;
  const offset = (page - 1) * limit;

  const query = `SELECT * FROM posts LIMIT ${limit} OFFSET ${offset}`;

  db.query(query, (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to fetch posts" });
    } else {
      res.json(result);
    }
  });
});

// GET a single post
app.get("/posts/:id", (req, res) => {
  const { id } = req.params;

  const query = "SELECT * FROM posts WHERE id = ?";

  db.query(query, [id], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to fetch post" });
    } else {
      if (result.length === 0) {
        res.status(404).json({ error: "Post not found" });
      } else {
        res.json(result[0]);
      }
    }
  });
});

// CREATE a post
app.post("/posts", (req, res) => {
  const { title, body } = req.body;

  const query = "INSERT INTO posts (title, body) VALUES (?, ?)";

  db.query(query, [title, body], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to create post" });
    } else {
      res.status(201).json({ id: result.insertId, title, body });
    }
  });
});

// UPDATE a post
app.put("/posts/:id", (req, res) => {
  const { id } = req.params;
  const { title, body } = req.body;

  const query = "UPDATE posts SET title = ?, body = ? WHERE id = ?";

  db.query(query, [title, body, id], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to update post" });
    } else {
      if (result.affectedRows === 0) {
        res.status(404).json({ error: "Post not found" });
      } else {
        res.json({ id, title, body });
      }
    }
  });
});

// DELETE a post
app.delete("/posts/:id", (req, res) => {
  const { id } = req.params;

  const query = "DELETE FROM posts WHERE id = ?";

  db.query(query, [id], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to delete post" });
    } else {
      if (result.affectedRows === 0) {
        res.status(404).json({ error: "Post not found" });
      } else {
        res.sendStatus(204);
      }
    }
  });
});

const port = 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
