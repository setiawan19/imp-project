## Mukri Setiawan Baguna :love*letter: _setiawanmukri@gmail.com*

#### This app is a simple app for CRUD post. Using nodeJS for The Backend side and ReactJS for The Frontend side

[LinkedIn](https://www.linkedin.com/in/mukri-setiawan-baguna-00837a133/) |
:octocat: [GitHub](https://github.com/setiawan19)
