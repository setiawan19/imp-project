import { ChakraProvider, Box, Container, Button } from "@chakra-ui/react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import PostList from "./components/PostList";
import PostDetail from "./components/PostDetail";
import CreatePost from "./components/CreatePost";
import EditPost from "./components/EditPost";
import DeletePost from "./components/DeletePost";

function App() {
  return (
    <ChakraProvider>
      <Container maxW="container.md" mt="4">
        <Router>
          <Box mb="4">
            <Link to="/posts">
              <Button>List Posts</Button>
            </Link>
            <Link to="/posts/create">
              <Button ml="2">Create Post</Button>
            </Link>
          </Box>
          <Routes>
            <Route path="/posts/create" element={<CreatePost />} />
            <Route path="/posts/:id/edit" element={<EditPost />} />
            <Route path="/posts/:id/delete" element={<DeletePost />} />
            <Route path="/posts/:id" element={<PostDetail />} />
            <Route path="/posts" element={<PostList />} />
          </Routes>
        </Router>
      </Container>
    </ChakraProvider>
  );
}

export default App;
