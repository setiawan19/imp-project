import axios from "axios";
import { useQuery, useMutation, useQueryClient } from "react-query";

const API_URL = "http://localhost:3000/posts"; // backend API URL

export const getPosts = () => axios.get(API_URL);

export const getPost = (postId) => axios.get(`${API_URL}/${postId}`);

export const createPost = (data) => axios.post(API_URL, data);

export const updatePost = (postId, data) =>
  axios.put(`${API_URL}/${postId}`, data);

export const deletePost = (postId) => axios.delete(`${API_URL}/${postId}`);

export const usePosts = () => useQuery("posts", getPosts);

export const usePost = (postId) =>
  useQuery(["post", postId], () => getPost(postId));

export const useCreatePost = () => {
  const queryClient = useQueryClient();
  return useMutation(createPost, {
    onSuccess: () => {
      queryClient.invalidateQueries("posts");
    },
  });
};

export const useUpdatePost = () => {
  const queryClient = useQueryClient();
  return useMutation(updatePost, {
    onSuccess: () => {
      queryClient.invalidateQueries("posts");
    },
  });
};

export const useDeletePost = () => {
  const queryClient = useQueryClient();
  return useMutation(deletePost, {
    onSuccess: () => {
      queryClient.invalidateQueries("posts");
    },
  });
};
