import { Box, Heading, Button } from "@chakra-ui/react";
import { useForm } from "react-hook-form";
import { useCreatePost } from "../api";

const CreatePost = () => {
  const { register, handleSubmit } = useForm();
  const createPostMutation = useCreatePost();

  const onSubmit = async (data) => {
    try {
      await createPostMutation.mutateAsync(data);
    } catch (error) {
      console.error("Failed to create post:", error);
    }
  };

  return (
    <Box>
      <Heading>Create Post</Heading>
      <form onSubmit={() => handleSubmit(onSubmit)}>
        <input
          type="text"
          name="title"
          placeholder="Title"
          ref={register({ required: true })}
        />
        <textarea
          name="body"
          placeholder="Body"
          ref={register({ required: true })}
        />
        <Button type="submit">Submit</Button>
      </form>
    </Box>
  );
};

export default CreatePost;
