import { Box, Heading, Button, Text } from "@chakra-ui/react";
import { useForm } from "react-hook-form";
import { useParams } from "react-router-dom";
import { usePost, useUpdatePost } from "../api";

const EditPost = () => {
  const { id } = useParams();
  const { data: post, isLoading } = usePost(id);
  const { register, handleSubmit } = useForm();
  const updatePostMutation = useUpdatePost();

  const onSubmit = async (data) => {
    try {
      await updatePostMutation.mutateAsync(id, data);
    } catch (error) {
      console.error("Failed to update post:", error);
    }
  };

  if (isLoading) {
    return <Text>Loading...</Text>;
  }

  return (
    <Box>
      <Heading>Edit Post</Heading>
      <form onSubmit={handleSubmit(onSubmit)}>
        <input
          type="text"
          name="title"
          placeholder="Title"
          defaultValue={post.title}
          ref={register({ required: true })}
        />
        <textarea
          name="body"
          placeholder="Body"
          defaultValue={post.body}
          ref={register({ required: true })}
        />
        <Button type="submit">Submit</Button>
      </form>
    </Box>
  );
};

export default EditPost;
