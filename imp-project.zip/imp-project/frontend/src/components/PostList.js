import { Box, Heading, Text, Button, Stack } from "@chakra-ui/react";
import { usePosts, useDeletePost } from "../api";

const PostList = () => {
  const { data: posts, isLoading } = usePosts();
  const deletePostMutation = useDeletePost();

  const handleDeletePost = async (postId) => {
    try {
      await deletePostMutation.mutateAsync(postId);
    } catch (error) {
      console.error("Failed to delete post:", error);
    }
  };

  if (isLoading) {
    return <Text>Loading...</Text>;
  }

  return (
    <Box>
      <Heading>Posts</Heading>
      {posts.map((post) => (
        <Box key={post.id} borderWidth="1px" borderRadius="md" p="4" mt="4">
          <Heading as="h3" size="md">
            {post.title}
          </Heading>
          <Text>{post.body}</Text>
          <Stack direction="row" mt="2">
            <Button colorScheme="blue" size="sm" mr="2">
              Edit
            </Button>
            <Button
              colorScheme="red"
              size="sm"
              onClick={() => handleDeletePost(post.id)}>
              Delete
            </Button>
          </Stack>
        </Box>
      ))}
    </Box>
  );
};

export default PostList;
