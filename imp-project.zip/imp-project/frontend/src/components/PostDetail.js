import { Box, Heading, Text } from "@chakra-ui/react";
import { useParams } from "react-router-dom";
import { usePost } from "../api";

const PostDetail = () => {
  const { id } = useParams();
  const { data: post, isLoading } = usePost(id);

  if (isLoading) {
    return <Text>Loading...</Text>;
  }

  return (
    <Box>
      <Heading>{post.title}</Heading>
      <Text>{post.body}</Text>
    </Box>
  );
};

export default PostDetail;
