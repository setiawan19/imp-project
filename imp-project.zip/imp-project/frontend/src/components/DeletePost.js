import { Box, Heading, Button } from "@chakra-ui/react";
import { useParams, useNavigate } from "react-router-dom";

import { useDeletePost } from "../api";

const DeletePost = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const deletePostMutation = useDeletePost();

  const handleDeletePost = async () => {
    try {
      await deletePostMutation.mutateAsync(id);
      navigate("/posts");
    } catch (error) {
      console.error("Failed to delete post:", error);
    }
  };

  return (
    <Box>
      <Heading>Delete Post</Heading>
      <Button colorScheme="red" onClick={handleDeletePost}>
        Confirm Delete
      </Button>
    </Box>
  );
};

export default DeletePost;
